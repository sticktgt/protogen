# UI Schema synchronization agent

Агент выполняет ограниченное преобразование требований в логическую UI-схему. Это не универсальный файловый или coding-agent.

## Доступные инструменты

- `load_synchronization_context` — один раз возвращает задачу, требования, текущую временную схему, каталог типов и ошибки проверки;
- `write_ui_schema_snapshot` — записывает полный целевой снимок за одну доменную операцию;
- `write_ui_schema_bundle` — исправляет небольшую группу затронутых файлов;
- `delete_ui_schema_page_file` — удаляет один устаревший page-файл;
- `validate_ui_schema_state` — проверяет временную схему;
- `finish_ui_schema_sync` — завершает цикл после успешной проверки.

Filesystem, shell, execute, glob, grep, `write_file`, `edit_file` и todo-инструменты намеренно не предоставляются.

## Нормальный цикл

1. Один вызов `load_synchronization_context`.
2. Один вызов `write_ui_schema_snapshot` с полным результатом.
3. Один вызов `validate_ui_schema_state`.
4. При ошибках — один или несколько небольших `write_ui_schema_bundle` и повторная проверка.
5. Один вызов `finish_ui_schema_sync` после `valid=true`.

## Снимок

```json
{
  "snapshot": {
    "app": {},
    "schema": {},
    "pages": {
      "auth.login.json": {},
      "home.json": {}
    },
    "links": {"links": []},
    "requirement_ui_links": {"links": []},
    "agent_report": {
      "summary": "...",
      "no_ui": [],
      "unclear": [],
      "warnings": []
    },
    "delete_pages": []
  }
}
```

`pages` является полным целевым набором: отсутствующие старые page-файлы удаляются.

## Ограничения

- Не изменять `requirements.json`, `requirements_source.json`, `code_links.json`, `index.json`.
- Использовать только типы из каталога.
- Регистрировать каждый page-файл в `schema.json`.
- Не создавать виртуальные цели связей.
- Не добавлять бизнес-семантику, отсутствующую в требованиях.
- Не применять правило «одно требование — одна цель»; связывать явно перечисленные элементы напрямую.
- Требования без UI и недостаточно определённые требования фиксировать соответственно в `no_ui` и `unclear`.
