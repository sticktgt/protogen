# План синхронизации UI-схемы

## Анализ требований
- 108 требований (REQ-0001..REQ-0108)
- 11 групп требований: GRP-AUTH, GRP-NAV, GRP-PRODUCTS, GRP-ACCOUNTS, GRP-PAYMENTS, GRP-DEPOSITS, GRP-CREDITS, GRP-CARDS, GRP-ANALYTICS, GRP-REPORTS, GRP-API
- Проект: PRJ-BANK-FRONT-OFFICE (Банковский фронт-офис физического лица)

## Страницы для создания
1. **auth.login** - Вход в систему (REQ-0001..REQ-0007)
2. **home** - Главная страница (REQ-0008..REQ-0018)
3. **products.overview** - Банковские продукты (REQ-0019..REQ-0024)
4. **accounts.list** - Список счетов (REQ-0025..REQ-0036)
5. **payments.transfer** - Переводы между счетами (REQ-0037..REQ-0047)
6. **deposits.open** - Открытие вклада (REQ-0048..REQ-0058)
7. **credits.apply** - Заявка на кредит (REQ-0059..REQ-0067)
8. **cards.block** - Блокировка карты (REQ-0068..REQ-0076)
9. **analytics.spending** - Аналитика трат (REQ-0077..REQ-0083)
10. **reports.statement** - Выписка по счету (REQ-0084..REQ-0087)

## API требования (без UI)
- REQ-0093..REQ-0103 - API endpoints (no_ui)

## Навигационные требования (REQ-0104..REQ-0108)
- Связи между страницами

## Справочники (REQ-0088..REQ-0092)
- no_ui - данные для справочников

## Структура схемы
- app.json - корневая конфигурация и меню
- schema.json - общая схема приложения
- links.json - навигационные связи
- mappings/requirement_ui_links.json - связи требований с UI
- pages/*.json - файлы страниц
